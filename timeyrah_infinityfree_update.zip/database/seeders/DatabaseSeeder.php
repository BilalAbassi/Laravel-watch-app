<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => 'alexander.sterling@horology.vip'],
            [
                'name' => 'Alexander Sterling',
                'password' => 'password',
                'email_verified_at' => now(),
                'is_admin' => true,
            ]
        );

        $this->call([
            ProductSeeder::class,
            CouponSeeder::class,
            SpecAttributeSeeder::class,
            PageSectionSeeder::class,
        ]);
    }
}
